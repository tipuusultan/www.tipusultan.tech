<?php
require_once __DIR__ . '/system/config.php';
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/header.php';
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/download-highlights.php';
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/footer.php';