
     
<script src="./template/default/assets/js/vendor.min.js"></script>
</body>
</html>