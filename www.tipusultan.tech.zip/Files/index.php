<?php
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/header.php';
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/main.php';
include_once __DIR__ . '/template/' . TEMPLATE_NAME . '/footer.php';