<main>
    <?php include_once __DIR__ . '/features.php'; ?>
</main>